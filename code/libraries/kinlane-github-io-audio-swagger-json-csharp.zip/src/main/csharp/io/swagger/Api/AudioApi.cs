using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class AudioApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public AudioApi(String basePath = "https://audio.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// retrieves all audio pulls all audio, with filter by keyword
    /// </summary>
    /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Query">a text query to search across audio</param>
    
    /// <returns></returns>
    public List<audio>  GetAudio (string Appid, string Appkey, string Query) {
      // create path and map variables
      var path = "/audio/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Query != null){
        queryParams.Add("query", apiInvoker.ParameterToString(Query));
      }
      

      

      

      try {
        if (typeof(List<audio>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<audio>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<audio>) ApiInvoker.deserialize(response, typeof(List<audio>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add audio add a new audio
    /// </summary>
    /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Name">name of the audio</param>
     /// <param name="Description">description of the audio</param>
     /// <param name="Url">url of the audio</param>
     /// <param name="ThumbnailUrl">thumbnailUrl of the audio</param>
     /// <param name="Creator">creator of the audio</param>
    
    /// <returns></returns>
    public List<audio>  AddAudio (string Appid, string Appkey, string Name, string Description, string Url, string ThumbnailUrl, string Creator) {
      // create path and map variables
      var path = "/audio/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (ThumbnailUrl != null){
        queryParams.Add("thumbnailUrl", apiInvoker.ParameterToString(ThumbnailUrl));
      }
      if (Creator != null){
        queryParams.Add("creator", apiInvoker.ParameterToString(Creator));
      }
      

      

      if (Appid != null){
        if(Appid is byte[]) {
          formParams.Add("appid", Appid);
        } else {
          formParams.Add("appid", apiInvoker.ParameterToString(Appid));
        }
      }
      if (Appkey != null){
        if(Appkey is byte[]) {
          formParams.Add("appkey", Appkey);
        } else {
          formParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
        }
      }
      if (Name != null){
        if(Name is byte[]) {
          formParams.Add("name", Name);
        } else {
          formParams.Add("name", apiInvoker.ParameterToString(Name));
        }
      }
      if (Description != null){
        if(Description is byte[]) {
          formParams.Add("description", Description);
        } else {
          formParams.Add("description", apiInvoker.ParameterToString(Description));
        }
      }
      if (Url != null){
        if(Url is byte[]) {
          formParams.Add("url", Url);
        } else {
          formParams.Add("url", apiInvoker.ParameterToString(Url));
        }
      }
      

      try {
        if (typeof(List<audio>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<audio>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<audio>) ApiInvoker.deserialize(response, typeof(List<audio>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// Retrieve a audio using its ID Returns the audio detail
    /// </summary>
    /// <param name="AudioId">unique id for the audio</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<audio>  GetAudio_1 (int? AudioId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/audio/{audio_id}/".Replace("{format}","json").Replace("{" + "audio_id" + "}", apiInvoker.ParameterToString(AudioId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<audio>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<audio>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<audio>) ApiInvoker.deserialize(response, typeof(List<audio>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// update audio update audio
    /// </summary>
    /// <param name="AudioId">unique id for the audio</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
     /// <param name="Name">name of the audio</param>
     /// <param name="Description">description of the audio</param>
     /// <param name="Url">url of the audio</param>
     /// <param name="ThumbnailUrl">thumbnailUrl of the audio</param>
     /// <param name="Creator">creator of the audio</param>
    
    /// <returns></returns>
    public List<audio>  UpdateAudio (int? AudioId, string Appid, string Appkey, string Name, string Description, string Url, string ThumbnailUrl, string Creator) {
      // create path and map variables
      var path = "/audio/{audio_id}/".Replace("{format}","json").Replace("{" + "audio_id" + "}", apiInvoker.ParameterToString(AudioId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (ThumbnailUrl != null){
        queryParams.Add("thumbnailUrl", apiInvoker.ParameterToString(ThumbnailUrl));
      }
      if (Creator != null){
        queryParams.Add("creator", apiInvoker.ParameterToString(Creator));
      }
      

      

      if (Appid != null){
        if(Appid is byte[]) {
          formParams.Add("appid", Appid);
        } else {
          formParams.Add("appid", apiInvoker.ParameterToString(Appid));
        }
      }
      if (Appkey != null){
        if(Appkey is byte[]) {
          formParams.Add("appkey", Appkey);
        } else {
          formParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
        }
      }
      if (Name != null){
        if(Name is byte[]) {
          formParams.Add("name", Name);
        } else {
          formParams.Add("name", apiInvoker.ParameterToString(Name));
        }
      }
      if (Description != null){
        if(Description is byte[]) {
          formParams.Add("description", Description);
        } else {
          formParams.Add("description", apiInvoker.ParameterToString(Description));
        }
      }
      if (Url != null){
        if(Url is byte[]) {
          formParams.Add("url", Url);
        } else {
          formParams.Add("url", apiInvoker.ParameterToString(Url));
        }
      }
      

      try {
        if (typeof(List<audio>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<audio>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<audio>) ApiInvoker.deserialize(response, typeof(List<audio>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete audio deletes an audio
    /// </summary>
    /// <param name="AudioId">unique id for the audio</param>
     /// <param name="Appid">your appid for accessing the API</param>
     /// <param name="Appkey">your appkey for accessing the API</param>
    
    /// <returns></returns>
    public List<audio>  DeleteAudio (int? AudioId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/audio/{audio_id}/".Replace("{format}","json").Replace("{" + "audio_id" + "}", apiInvoker.ParameterToString(AudioId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<audio>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<audio>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<audio>) ApiInvoker.deserialize(response, typeof(List<audio>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
