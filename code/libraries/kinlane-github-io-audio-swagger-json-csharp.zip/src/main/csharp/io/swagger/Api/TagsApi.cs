using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class TagsApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public TagsApi(String basePath = "https://audio.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// retrieve audio tags Returns the tags for an audio
    /// </summary>
    /// <param name="AudioId">id for audio</param>
     /// <param name="Appid">your appid for accessing the audio</param>
     /// <param name="Appkey">your appkey for accessing the audio</param>
    
    /// <returns></returns>
    public List<tag>  GetaudioTags (string AudioId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/audio/{audio_id}/tags/".Replace("{format}","json").Replace("{" + "audio_id" + "}", apiInvoker.ParameterToString(AudioId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add tag to audio add tag for audio
    /// </summary>
    /// <param name="AudioId">id for the audio</param>
     /// <param name="Appid">your appid for accessing the audio</param>
     /// <param name="Appkey">your appkey for accessing the audio</param>
     /// <param name="Tag">tag name</param>
    
    /// <returns></returns>
    public List<tag>  AddPeopleTag (string AudioId, string Appid, string Appkey, string Tag) {
      // create path and map variables
      var path = "/audio/{audio_id}/tags/".Replace("{format}","json").Replace("{" + "audio_id" + "}", apiInvoker.ParameterToString(AudioId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      

      

      if (Appid != null){
        if(Appid is byte[]) {
          formParams.Add("appid", Appid);
        } else {
          formParams.Add("appid", apiInvoker.ParameterToString(Appid));
        }
      }
      if (Appkey != null){
        if(Appkey is byte[]) {
          formParams.Add("appkey", Appkey);
        } else {
          formParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
        }
      }
      if (Tag != null){
        if(Tag is byte[]) {
          formParams.Add("tag", Tag);
        } else {
          formParams.Add("tag", apiInvoker.ParameterToString(Tag));
        }
      }
      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete a audio tag deletes a tag applied to audio
    /// </summary>
    /// <param name="AudioId">id for the audio</param>
     /// <param name="Appid">your appid for accessing the audio</param>
     /// <param name="Appkey">your appkey for accessing the audio</param>
     /// <param name="Tag">tag to remove from audio</param>
    
    /// <returns></returns>
    public List<tag>  DeleteaudioTag (string AudioId, string Appid, string Appkey, string Tag) {
      // create path and map variables
      var path = "/audio/{audio_id}/tags/{tag}".Replace("{format}","json").Replace("{" + "audio_id" + "}", apiInvoker.ParameterToString(AudioId)).Replace("{" + "tag" + "}", apiInvoker.ParameterToString(Tag));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
