using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Audio {
    

    /* unique id for the audio */
    
    public int? AudioId { get; set; }

    

    /* name of the audio */
    
    public string Name { get; set; }

    

    /* description for the audio */
    
    public string Description { get; set; }

    

    /* url for the audio contact */
    
    public string Url { get; set; }

    

    /* thumbnail url for the audio contact */
    
    public string ThumbnailUrl { get; set; }

    

    /* creator for the audio contact */
    
    public string Creator { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Audio {\n");
      
      sb.Append("  AudioId: ").Append(AudioId).Append("\n");
      
      sb.Append("  Name: ").Append(Name).Append("\n");
      
      sb.Append("  Description: ").Append(Description).Append("\n");
      
      sb.Append("  Url: ").Append(Url).Append("\n");
      
      sb.Append("  ThumbnailUrl: ").Append(ThumbnailUrl).Append("\n");
      
      sb.Append("  Creator: ").Append(Creator).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}