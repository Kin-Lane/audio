package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Audio  {
  
  private Integer audioId = null;
  private String name = null;
  private String description = null;
  private String url = null;
  private String thumbnailUrl = null;
  private String creator = null;

  
  /**
   * unique id for the audio
   **/
  @ApiModelProperty(value = "unique id for the audio")
  @JsonProperty("audio_id")
  public Integer getAudioId() {
    return audioId;
  }
  public void setAudioId(Integer audioId) {
    this.audioId = audioId;
  }

  
  /**
   * name of the audio
   **/
  @ApiModelProperty(value = "name of the audio")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  
  /**
   * description for the audio
   **/
  @ApiModelProperty(value = "description for the audio")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  
  /**
   * url for the audio contact
   **/
  @ApiModelProperty(value = "url for the audio contact")
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  
  /**
   * thumbnail url for the audio contact
   **/
  @ApiModelProperty(value = "thumbnail url for the audio contact")
  @JsonProperty("thumbnailUrl")
  public String getThumbnailUrl() {
    return thumbnailUrl;
  }
  public void setThumbnailUrl(String thumbnailUrl) {
    this.thumbnailUrl = thumbnailUrl;
  }

  
  /**
   * creator for the audio contact
   **/
  @ApiModelProperty(value = "creator for the audio contact")
  @JsonProperty("creator")
  public String getCreator() {
    return creator;
  }
  public void setCreator(String creator) {
    this.creator = creator;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Audio {\n");
    
    sb.append("  audioId: ").append(audioId).append("\n");
    sb.append("  name: ").append(name).append("\n");
    sb.append("  description: ").append(description).append("\n");
    sb.append("  url: ").append(url).append("\n");
    sb.append("  thumbnailUrl: ").append(thumbnailUrl).append("\n");
    sb.append("  creator: ").append(creator).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
