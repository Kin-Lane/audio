#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGAudio
@end
  
@interface SWGAudio : SWGObject

/* unique id for the audio [optional]
 */
@property(nonatomic) NSNumber* audio_id;
/* name of the audio [optional]
 */
@property(nonatomic) NSString* name;
/* description for the audio [optional]
 */
@property(nonatomic) NSString* _description;
/* url for the audio contact [optional]
 */
@property(nonatomic) NSString* url;
/* thumbnail url for the audio contact [optional]
 */
@property(nonatomic) NSString* thumbnailUrl;
/* creator for the audio contact [optional]
 */
@property(nonatomic) NSString* creator;

@end
