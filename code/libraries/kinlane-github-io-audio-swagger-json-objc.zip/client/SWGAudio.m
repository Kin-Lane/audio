#import "SWGAudio.h"

@implementation SWGAudio
  
+ (JSONKeyMapper *)keyMapper
{
  return [[JSONKeyMapper alloc] initWithDictionary:@{ @"audio_id": @"audio_id", @"name": @"name", @"description": @"_description", @"url": @"url", @"thumbnailUrl": @"thumbnailUrl", @"creator": @"creator" }];
}

+ (BOOL)propertyIsOptional:(NSString *)propertyName
{
  NSArray *optionalProperties = @[@"audio_id", @"name", @"_description", @"url", @"thumbnailUrl", @"creator"];

  if ([optionalProperties containsObject:propertyName]) {
    return YES;
  }
  else {
    return NO;
  }
}

@end
