#import <Foundation/Foundation.h>
#import "SWGAudio.h"
#import "SWGObject.h"


@interface SWGAudioApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGAudioApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieves all audio
 pulls all audio, with filter by keyword

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param query a text query to search across audio
 

 return type: NSArray<SWGAudio>*
 */
-(NSNumber*) getAudioWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     query:(NSString*) query 
    
    completionHandler: (void (^)(NSArray<SWGAudio>* output, NSError* error))completionBlock;
    


/**

 add audio
 add a new audio

 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param name name of the audio
 @param _description description of the audio
 @param url url of the audio
 @param thumbnailUrl thumbnailUrl of the audio
 @param creator creator of the audio
 

 return type: NSArray<SWGAudio>*
 */
-(NSNumber*) addAudioWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     name:(NSString*) name 
     _description:(NSString*) _description 
     url:(NSString*) url 
     thumbnailUrl:(NSString*) thumbnailUrl 
     creator:(NSString*) creator 
    
    completionHandler: (void (^)(NSArray<SWGAudio>* output, NSError* error))completionBlock;
    


/**

 Retrieve a audio using its ID
 Returns the audio detail

 @param audio_id unique id for the audio
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGAudio>*
 */
-(NSNumber*) getAudio_1WithCompletionBlock :(NSNumber*) audio_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGAudio>* output, NSError* error))completionBlock;
    


/**

 update audio
 update audio

 @param audio_id unique id for the audio
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 @param name name of the audio
 @param _description description of the audio
 @param url url of the audio
 @param thumbnailUrl thumbnailUrl of the audio
 @param creator creator of the audio
 

 return type: NSArray<SWGAudio>*
 */
-(NSNumber*) updateAudioWithCompletionBlock :(NSNumber*) audio_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     name:(NSString*) name 
     _description:(NSString*) _description 
     url:(NSString*) url 
     thumbnailUrl:(NSString*) thumbnailUrl 
     creator:(NSString*) creator 
    
    completionHandler: (void (^)(NSArray<SWGAudio>* output, NSError* error))completionBlock;
    


/**

 delete audio
 deletes an audio

 @param audio_id unique id for the audio
 @param appid your appid for accessing the API
 @param appkey your appkey for accessing the API
 

 return type: NSArray<SWGAudio>*
 */
-(NSNumber*) deleteAudioWithCompletionBlock :(NSNumber*) audio_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGAudio>* output, NSError* error))completionBlock;
    



@end