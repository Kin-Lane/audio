#import "SWGObject.h"

@implementation SWGObject
@end
