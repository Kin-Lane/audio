#import <Foundation/Foundation.h>
#import "SWGTag.h"
#import "SWGObject.h"


@interface SWGTagsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGTagsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve audio tags
 Returns the tags for an audio

 @param audio_id id for audio
 @param appid your appid for accessing the audio
 @param appkey your appkey for accessing the audio
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) getaudioTagsWithCompletionBlock :(NSString*) audio_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 add tag to audio
 add tag for audio

 @param audio_id id for the audio
 @param appid your appid for accessing the audio
 @param appkey your appkey for accessing the audio
 @param tag tag name
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) addPeopleTagWithCompletionBlock :(NSString*) audio_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 delete a audio tag
 deletes a tag applied to audio

 @param audio_id id for the audio
 @param appid your appid for accessing the audio
 @param appkey your appkey for accessing the audio
 @param tag tag to remove from audio
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) deleteaudioTagWithCompletionBlock :(NSString*) audio_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    



@end