require "uri"

class AudioApi
  basePath = "https://audio.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieves all audio
  # pulls all audio, with filter by keyword
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @option opts [string] :query a text query to search across audio
  # @return array[audio]
  def self.get_audio(appid, appkey, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/audio/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'query'] = opts[:'query'] if opts[:'query']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| audio.new(response) }
  end

  # add audio
  # add a new audio
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param name name of the audio
  # @param url url of the audio
  # @param [Hash] opts the optional parameters
  # @option opts [string] :description description of the audio
  # @option opts [string] :thumbnail_url thumbnailUrl of the audio
  # @option opts [string] :creator creator of the audio
  # @return array[audio]
  def self.add_audio(appid, appkey, name, url, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "name is required" if name.nil?
    raise "url is required" if url.nil?

    # resource path
    path = "/audio/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'thumbnailUrl'] = opts[:'thumbnail_url'] if opts[:'thumbnail_url']
    query_params[:'creator'] = opts[:'creator'] if opts[:'creator']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}
    form_params["appid"] = appid
    form_params["appkey"] = appkey
    form_params["name"] = name
    form_params["url"] = url
    form_params["description"] = opts[:'description'] if opts[:'description']

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| audio.new(response) }
  end

  # Retrieve a audio using its ID
  # Returns the audio detail
  # @param audio_id unique id for the audio
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[audio]
  def self.get_audio_1(audio_id, appid, appkey, opts = {})
    # verify existence of params
    raise "audio_id is required" if audio_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/audio/{audio_id}/".sub('{format}','json').sub('{' + 'audio_id' + '}', audio_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| audio.new(response) }
  end

  # update audio
  # update audio
  # @param audio_id unique id for the audio
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param name name of the audio
  # @param url url of the audio
  # @param [Hash] opts the optional parameters
  # @option opts [string] :description description of the audio
  # @option opts [string] :thumbnail_url thumbnailUrl of the audio
  # @option opts [string] :creator creator of the audio
  # @return array[audio]
  def self.update_audio(audio_id, appid, appkey, name, url, opts = {})
    # verify existence of params
    raise "audio_id is required" if audio_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "name is required" if name.nil?
    raise "url is required" if url.nil?

    # resource path
    path = "/audio/{audio_id}/".sub('{format}','json').sub('{' + 'audio_id' + '}', audio_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'thumbnailUrl'] = opts[:'thumbnail_url'] if opts[:'thumbnail_url']
    query_params[:'creator'] = opts[:'creator'] if opts[:'creator']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}
    form_params["appid"] = appid
    form_params["appkey"] = appkey
    form_params["name"] = name
    form_params["url"] = url
    form_params["description"] = opts[:'description'] if opts[:'description']

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:PUT, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| audio.new(response) }
  end

  # delete audio
  # deletes an audio
  # @param audio_id unique id for the audio
  # @param appid your appid for accessing the API
  # @param appkey your appkey for accessing the API
  # @param [Hash] opts the optional parameters
  # @return array[audio]
  def self.delete_audio(audio_id, appid, appkey, opts = {})
    # verify existence of params
    raise "audio_id is required" if audio_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/audio/{audio_id}/".sub('{format}','json').sub('{' + 'audio_id' + '}', audio_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| audio.new(response) }
  end
end
