require "uri"

class TagsApi
  basePath = "https://audio.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieve audio tags
  # Returns the tags for an audio
  # @param audio_id id for audio
  # @param appid your appid for accessing the audio
  # @param appkey your appkey for accessing the audio
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.getaudio_tags(audio_id, appid, appkey, opts = {})
    # verify existence of params
    raise "audio_id is required" if audio_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/audio/{audio_id}/tags/".sub('{format}','json').sub('{' + 'audio_id' + '}', audio_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end

  # add tag to audio
  # add tag for audio
  # @param audio_id id for the audio
  # @param appid your appid for accessing the audio
  # @param appkey your appkey for accessing the audio
  # @param tag tag name
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.add_people_tag(audio_id, appid, appkey, tag, opts = {})
    # verify existence of params
    raise "audio_id is required" if audio_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tag is required" if tag.nil?

    # resource path
    path = "/audio/{audio_id}/tags/".sub('{format}','json').sub('{' + 'audio_id' + '}', audio_id.to_s)

    # query parameters
    query_params = {}

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}
    form_params["appid"] = appid
    form_params["appkey"] = appkey
    form_params["tag"] = tag

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end

  # delete a audio tag
  # deletes a tag applied to audio
  # @param audio_id id for the audio
  # @param appid your appid for accessing the audio
  # @param appkey your appkey for accessing the audio
  # @param tag tag to remove from audio
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.deleteaudio_tag(audio_id, appid, appkey, tag, opts = {})
    # verify existence of params
    raise "audio_id is required" if audio_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tag is required" if tag.nil?

    # resource path
    path = "/audio/{audio_id}/tags/{tag}".sub('{format}','json').sub('{' + 'audio_id' + '}', audio_id.to_s).sub('{' + 'tag' + '}', tag.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end
end
