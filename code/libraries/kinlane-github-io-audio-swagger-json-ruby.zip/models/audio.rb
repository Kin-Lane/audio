
class Audio
  attr_accessor :audio_id, :name, :description, :url, :thumbnail_url, :creator
  # :internal => :external
  def self.attribute_map
    {
      :audio_id => :'audio_id',
      :name => :'name',
      :description => :'description',
      :url => :'url',
      :thumbnail_url => :'thumbnailUrl',
      :creator => :'creator'
      
    }
  end

  def initialize(attributes = {})
    return if attributes.empty?
    # Morph attribute keys into undescored rubyish style
    
    if self.class.attribute_map[:"audio_id"]
      @audio_id = attributes["audio_id"]
    end
    
    if self.class.attribute_map[:"name"]
      @name = attributes["name"]
    end
    
    if self.class.attribute_map[:"description"]
      @description = attributes["description"]
    end
    
    if self.class.attribute_map[:"url"]
      @url = attributes["url"]
    end
    
    if self.class.attribute_map[:"thumbnail_url"]
      @thumbnail_url = attributes["thumbnailUrl"]
    end
    
    if self.class.attribute_map[:"creator"]
      @creator = attributes["creator"]
    end
    
  end

  def to_body
    body = {}
    self.class.attribute_map.each_pair do |key, value|
      body[value] = self.send(key) unless self.send(key).nil?
    end
    body
  end
end
